# Load Calculator Web App

This is a simple web-based tool to compute motor load horsepower and current from input power, voltage, power factor, and efficiency.

## How to Use

1. Open `index.html` in your browser to use locally.
2. Or, upload to a GitHub repository and enable GitHub Pages:

### GitHub Pages Deployment

- Create a new repository on [github.com](https://github.com)
- Upload this file (`index.html`) to the root of the repository
- Go to `Settings > Pages`
  - Source: `main` branch, root (`/`)
- Visit your deployed web app at: `https://yourusername.github.io/repo-name/`
